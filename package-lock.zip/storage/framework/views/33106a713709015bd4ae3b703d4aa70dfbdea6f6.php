</div>
    <div class="modal-footer">
        <button type="button" wire:click.prevent="resetUI()" class="btn btn-outline-danger close-btn text-danger" data-dismiss="modal"><i class="fas fa-ban"></i> CERRAR</button>
        
        <?php if($selected_id < 1): ?>
        <button type="button" wire:click.prevent="Store()" class="btn btn-dark close-modal"><i class="fas fa-save"></i> GUARDAR</button>
        <?php else: ?>
        <button type="button" wire:click.prevent="Update()" class="btn btn-dark close-modal"><i class="fas fa-redo-alt"></i> ACTUALIZAR</button>
        <?php endif; ?>
    </div>
</div>
</div>
</div><?php /**PATH C:\Users\José\Desktop\Sistemas\inventario\resources\views/commom/modalFooter.blade.php ENDPATH**/ ?>