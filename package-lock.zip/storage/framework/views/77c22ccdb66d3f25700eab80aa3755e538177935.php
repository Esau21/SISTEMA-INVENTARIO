

<?php $__env->startSection('content'); ?>
 
    <div class="container">
    <div class="row">
        <div class="col-12 col-lg-6 mt-5">
            <b><h5 class="display-4 text-left text-primary">Bienvenidos al sistema VentasLite</h5></b>
            <b><p class="lead text-left text-primary" >Bienvendios al sistema de control de ventas puedes ver las utimas actualizaciones del sistema
                by EsauDev
            </p></b>
            <a class="btn btn-lg btn-block btn-primary" href="">Contactame</a>
        </div>
    </div>

    <div class="col-12 col-lg-12">
        <img class="img-fluid mb-4" height="400px;" width="400px;" src="/img/hu.png" alt="Desarrollo web">
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.theme.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\José\Desktop\Sistemas\inventario\resources\views/home.blade.php ENDPATH**/ ?>