<div class="footer-wrapper">
                <div class="footer-section f-section-1">
                    <p class="text-center">SMVentas<a target="_blank" href="https://softmilenial.com"></a>, By Edgar Dev</p>
                </div>
                
</div><?php /**PATH C:\Users\José\Desktop\Sistemas\inventario\resources\views/layouts/theme/footer.blade.php ENDPATH**/ ?>