<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('css/factura.css')); ?>">
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title', 'M.A.E S.A DE C.V'); ?></title>


</head>

<body>
    <header class="row">
        <div class="logoholder text-center">
            <img src="<?php echo e(asset('img/ma.png')); ?>" alt="LOGO" width="70px;" height="70px;">
        </div>
        <!--.logoholder-->

        <div class="me">
            <p contenteditable>
                <strong>M.A.E S.A. de C.V.</strong><br>
                El salvador<br>
                Grupo 9<br>

            </p>
        </div>
        <!--.me-->

        <div class="info">
            <p contenteditable>
                Web: <a href="https:carwash-mae.xyz">https:carwash-mae.xyz</a><br>
                E-mail: <a href="mailto:info@obedalvarado.pw">maesv123@gmail.com</a><br>
                Tel: +503-78676767<br>
                Twitter: @maesv123
            </p>
        </div><!-- .info -->

    </header>

    <div class="card mb-4">
        <table width="100%">
            <tr>
                <td><strong>M.A.E:</strong>Gracias por preferirnos</td>
                <td><strong>SERVICIOS PROFESIONALES:</strong> M.A.E S.A DE C.V</td>
            </tr>
        </table>
    </div>

    <br />

    <div class="card">
        <div class="card-header">
            <h6 class="text-left text-uppercase" style="color: #3B3F5C">DETALLES DE LA FACTURA</h6>
        </div>
        <div class="card-body">
            <table width="100%">
                <thead style="background-color: lightgray;">
                    <tr invoice_detail>
                        <th>#</th>
                        <th>CLIENTE</th>
                        <th>PRODUCTO</th>
                        <th>CANTIDAD</th>
                        <th>IVA</th>
                        <th>SUB TOTAL</th>
                        <th>TOTAL</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $saleDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($detail->id); ?></th>
                            <td align="center"><?php echo e($detail->sale->user->name); ?></td>
                            <td align="center"><?php echo e($detail->product->name); ?></td>
                            <td align="center"><?php echo e($detail->quantity); ?></td>
                            <td align="center">$<?php echo e(number_format($detail->sale->iva, 2)); ?></td>
                            <td align="center">$<?php echo e(number_format($detail->price, 2)); ?></td>
                            <td align="center">
                                $<?php echo e(number_format($detail->quantity * $detail->price * (1 + $iva), 2)); ?></td>
                            </td>
                        </tr>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="3"></td>
                        <td align="right">Subtotal $</td>
                        <td align="right">$<?php echo e(number_format($detail->quantity * $detail->price * (1 + $iva), 2)); ?>

                        </td>
                    </tr>
                    <tr>
                        <td colspan="3"></td>
                        <td align="right">IVA $</td>
                        <td align="right">$<?php echo e($detail->sale->iva); ?></td>
                    </tr>
                    <tr>
                        <td colspan="3"></td>
                        <td align="right">Total $</td>
                        <td align="right">$<?php echo e(number_format($sale->total * (1 + $iva), 2)); ?></td>
                    </tr>
                </tfoot>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>

</body>

</html>
<?php /**PATH C:\Users\José\Desktop\Sistemas\inventario\resources\views/pdf/ventas_unique.blade.php ENDPATH**/ ?>