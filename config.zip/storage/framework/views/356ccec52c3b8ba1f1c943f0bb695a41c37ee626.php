<div class="row justify-content-between">
    <div class="col-lg-4 col-md-4 col-sm-12">
        <div class="input-group mb-4">
            <div class="input-group-prepend">
                <span class="input-group-text input-gp">
                    <i class="fas fa-search"></i>
                </span>
            </div>
            <input type="text" wire:model="search" placeholder="Buscar" class="form-control">
        </div>
    </div>
</div><?php /**PATH C:\Users\José\Desktop\Sistemas\inventario\resources\views/commom/searchbox.blade.php ENDPATH**/ ?>