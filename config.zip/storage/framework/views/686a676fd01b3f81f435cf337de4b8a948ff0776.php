        <div>
            <style></style>



        <div class="row layout-top-spacing">

            <div class="col-sm-12 col-md-8">
            
            <?php echo $__env->make('livewire.pos.partials.detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <br>
            <center>
            
            </center>
            </div>


            <div class="col-sm-12 col-md-4">
                
                <?php echo $__env->make('livewire.pos.partials.total', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



                
                <?php echo $__env->make('livewire.pos.partials.coins', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

        </div>

    </div>



    <script src="<?php echo e(asset('js/keypress.js')); ?>"></script>
    <script src="<?php echo e(asset('js/onscan.js')); ?>"></script>

        <?php echo $__env->make('livewire.pos.scripts.events', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('livewire.pos.scripts.general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('livewire.pos.scripts.scan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('livewire.pos.scripts.shortcuts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\José\Desktop\Sistemas\inventario\resources\views/livewire/pos/component.blade.php ENDPATH**/ ?>