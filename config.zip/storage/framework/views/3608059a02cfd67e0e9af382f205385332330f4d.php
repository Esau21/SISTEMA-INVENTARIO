<div class="header-container  fixed-top">
    <header class="header navbar navbar-expand-sm">
        <ul class="navbar-item flex-row">
            <li class="nav-item theme-logo">
                <a class="text-primary" href="home">
                    <img src="<?php echo e(asset('img/edmae.png')); ?>" class="navbar-logo" width="300px;" height="300px;" alt="logo">
                    <b  style="font-size: 15px; color:#ffffff">M.A.E DE S.A DE C.V</b>
                </a>
            </li>
        </ul>

        <a href="javascript:void(0);" class="sidebarCollapse" data-placement="bottom"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-list"><line x1="8" y1="6" x2="21" y2="6"></line><line x1="8" y1="12" x2="21" y2="12"></line><line x1="8" y1="18" x2="21" y2="18"></line><line x1="3" y1="6" x2="3" y2="6"></line><line x1="3" y1="12" x2="3" y2="12"></line><line x1="3" y1="18" x2="3" y2="18"></line></svg></a>

       <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('search-controller', [])->html();
} elseif ($_instance->childHasBeenRendered('ch8fp6g')) {
    $componentId = $_instance->getRenderedChildComponentId('ch8fp6g');
    $componentTag = $_instance->getRenderedChildComponentTagName('ch8fp6g');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ch8fp6g');
} else {
    $response = \Livewire\Livewire::mount('search-controller', []);
    $html = $response->html();
    $_instance->logRenderedChild('ch8fp6g', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <ul class="navbar-item flex-row navbar-dropdown">

            <li class="nav-item dropdown user-profile-dropdown  ml-auto">
                <a href="javascript:void(0);" class="nav-link dropdown-toggle user" id="userProfileDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="far fa-user text-success fa-1x"></i>
                </a>
                <div class="dropdown-menu position-absolute animated fadeInUp" aria-labelledby="userProfileDropdown">
                    <div class="user-profile-section">
                        <div class="media mx-auto">
                            <img src="assets/img/Laravel-logo.jpg" class="img-fluid mr-2" alt="avatar">
                            <div class="media-body">
                                <h5>Edgar Dev</h5>
                                <p>Administrador</p>
                            </div>
                        </div>
                    </div>
                    <div class="dropdown-item">
                        <a href="user_profile.html">
                            <i class="fas fa-user"></i> <span>Mi Perfil</span>
                        </a>
                    </div>
                    
                 
                  <div class="dropdown-item">

                    <a href="<?php echo e(route('logout')); ?>"
                        onclick="event.preventDefault(); document.getElementById('logout-form').submit()">
                        
                        <i class="fas fa-sign-out-alt"></i>
                     
                        
                        <span>Log Out</span>
                    </a>
                    <form action="<?php echo e(route('logout')); ?>" method="POST" id="logout-form">
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
                </div>
            </li>
        </ul>
    </header>
</div><?php /**PATH C:\Users\José\Desktop\Sistemas\inventario\resources\views/layouts/theme/header.blade.php ENDPATH**/ ?>